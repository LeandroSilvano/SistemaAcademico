package leandrosoft.dialogos;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import leandrosoft.ferramentas.Controlador;
import leandrosoft.telas.MenuPrincipal;

public class CaixaAlteracaoTurma {

	public AnchorPane painel, painelFundo;
	
	private int codigoTurma;
	
	public CaixaAlteracaoTurma(int codigoTurmaParam) {
		
		this.codigoTurma = codigoTurmaParam;
	
		painel = new AnchorPane();
		
		painelFundo = new AnchorPane();
		painelFundo.setLayoutX(150);
		painelFundo.setLayoutY(200);
		
		ImageView imgFundo = new ImageView(getClass().getResource("../img/dialogoAlteraTurma.png").toString());
		
		TextField txtNomeTurma = new TextField();
		txtNomeTurma.setStyle("-fx-font-size: 20px;");
		txtNomeTurma.setLayoutX(50);
		txtNomeTurma.setLayoutY(100);
		txtNomeTurma.setPrefWidth(300);
		
		Button btnAlteraTurma = new Button("Alterar");
		btnAlteraTurma.setStyle("-fx-font-size: 20px;");
		btnAlteraTurma.setLayoutX(50);
		btnAlteraTurma.setLayoutY(150);
		
		btnAlteraTurma.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				
				if(txtNomeTurma.getText().toString().trim().isEmpty()){
					Controlador.mostrarNotificacao(MenuPrincipal.painel, 1, "Insira o novo nome da turma no campo de texto.");
				}
				else if(txtNomeTurma.getText().toString().length() > 10){
					Controlador.mostrarNotificacao(MenuPrincipal.painel, 1, "O limite do nome da turma � de 10 caracteres.");
				}
				else{
					
					if(alterarTurma(codigoTurma, txtNomeTurma.getText().toString())){
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 0, "Nome da turma alterado.");
						MenuPrincipal.filho.mudarSecao("conTurma");
					}
					else{
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
					}
					
				}
				
			}
		});
		
		Button btnCancela = new Button("Cancelar");
		btnCancela.setStyle("-fx-font-size: 20px;");
		btnCancela.setLayoutX(246);
		btnCancela.setLayoutY(150);
		
		btnCancela.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e){
				MenuPrincipal.filho.mudarSecao("conTurma");
			}
		});
		
		txtNomeTurma.requestFocus();
		
		painelFundo.getChildren().addAll(imgFundo, txtNomeTurma, btnAlteraTurma, btnCancela);
		
		Rectangle r = new Rectangle(0, 0, 2000, 2000);
		r.setFill(Color.TRANSPARENT);
		
		painel.getChildren().addAll(r, painelFundo);
	}
	
	private boolean alterarTurma(int codigoTurma, String novoNome){
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("UPDATE Turma SET nome = '" + novoNome + "' WHERE codigo = " + codigoTurma + ";");
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
}
