package leandrosoft.dialogos;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import leandrosoft.ferramentas.Controlador;
import leandrosoft.secoes.SecaoConsultaAlunoEtapa2;
import leandrosoft.telas.MenuPrincipal;

public class CaixaExclusaoAluno {

	public AnchorPane painel, painelFundo;
	
	private int codigoAluno;
	private int codigoTurmaInicial;
	private String nomeTurmaInicial;
	
	public CaixaExclusaoAluno(int codigoAlunoParam, int codigoTurmaParam, String nomeTurmaParam) {

		this.codigoAluno = codigoAlunoParam;
		this.codigoTurmaInicial = codigoTurmaParam;
		this.nomeTurmaInicial = nomeTurmaParam;
		
		painel = new AnchorPane();
		
		painelFundo = new AnchorPane();
		painelFundo.setLayoutX(150);
		painelFundo.setLayoutY(200);
		
		ImageView imgFundo = new ImageView(getClass().getResource("../img/dialogoExcluiAluno.png").toString());
		
		Label lblAviso = new Label("Excluir mesmo este aluno?");
		lblAviso.setLayoutX(50);
		lblAviso.setLayoutY(100);
		lblAviso.setStyle("-fx-font-size: 16px;");
		
		Button btnExcluir = new Button("Excluir");
		btnExcluir.setStyle("-fx-font-size: 20px;");
		btnExcluir.setLayoutX(50);
		btnExcluir.setLayoutY(150);
		
		btnExcluir.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				
				if(excluirAluno(codigoAluno)){
					Controlador.mostrarNotificacao(MenuPrincipal.painel, 0, "Aluno exclu�do.");
					
					SecaoConsultaAlunoEtapa2 conAluno2 = new SecaoConsultaAlunoEtapa2(codigoTurmaInicial, nomeTurmaInicial);
					MenuPrincipal.filho.getChildren().clear();
					MenuPrincipal.filho.getChildren().addAll(conAluno2.listaDeElementos);
				}
				else{
					Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
				}
				
			}
		});
		
		Button btnCancela = new Button("Cancelar");
		btnCancela.setStyle("-fx-font-size: 20px;");
		btnCancela.setLayoutX(246);
		btnCancela.setLayoutY(150);
		
		btnCancela.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				MenuPrincipal.filho.getChildren().remove(CaixaExclusaoAluno.this.painel);
			}
		});
		
		painelFundo.getChildren().addAll(imgFundo, lblAviso, btnExcluir, btnCancela);
		
		Rectangle r = new Rectangle(0, 0, 2000, 2000);
		r.setFill(Color.TRANSPARENT);

		painel.getChildren().addAll(r, painelFundo);
		
	}
	
	private boolean excluirAluno(int codigoAluno){
		boolean resultado = false;

		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLSemRetorno("DELETE FROM Aluno WHERE codigo = " + codigoAluno + ";");

			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
}
