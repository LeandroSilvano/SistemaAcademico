package leandrosoft.dialogos;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import leandrosoft.ferramentas.Controlador;
import leandrosoft.telas.MenuPrincipal;

public class CaixaAlteracaoMateria {

	public AnchorPane painel, painelFundo;
	
	private int codigoMateria;
	
	public CaixaAlteracaoMateria(int codigoMateriaParam) {

		this.codigoMateria = codigoMateriaParam;
		
		ImageView imgFundo = new ImageView(getClass().getResource("../img/dialogoAlteraMateria.png").toString());
		
		painel = new AnchorPane();
		
		painelFundo = new AnchorPane();
		painelFundo.setLayoutX(150);
		painelFundo.setLayoutY(200);
		
		TextField txtNomeMateria = new TextField();
		txtNomeMateria.setStyle("-fx-font-size: 20px;");
		txtNomeMateria.setLayoutX(50);
		txtNomeMateria.setLayoutY(100);
		txtNomeMateria.setPrefWidth(300);
		
		Button btnAlteraMateria = new Button("Alterar");
		btnAlteraMateria.setStyle("-fx-font-size: 20px;");
		btnAlteraMateria.setLayoutX(50);
		btnAlteraMateria.setLayoutY(150);
		
		btnAlteraMateria.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {

				if(txtNomeMateria.getText().toString().trim().isEmpty()){
					Controlador.mostrarNotificacao(MenuPrincipal.painel, 1, "O campo deve ser preenchido.");
					txtNomeMateria.requestFocus();
				}
				else if(txtNomeMateria.getText().toString().length() > 30){
					Controlador.mostrarNotificacao(MenuPrincipal.painel, 1, "O limite do nome da mat�ria � de 30 caracteres.");
					txtNomeMateria.requestFocus();
				}
				else{
					
					if(atualizarMateria(codigoMateria, txtNomeMateria.getText().toString())){
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 0, "Mat�ria atualizada.");
						MenuPrincipal.filho.mudarSecao("conMateria");
					}
					else{
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
					}
					
				}
				
			}
		});
		
		
		Button btnCancela = new Button("Cancelar");
		btnCancela.setStyle("-fx-font-size: 20px;");
		btnCancela.setLayoutX(246);
		btnCancela.setLayoutY(150);
		
		btnCancela.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				MenuPrincipal.filho.getChildren().remove(CaixaAlteracaoMateria.this.painel);
			}
		});
		
		
		painelFundo.getChildren().addAll(imgFundo, txtNomeMateria, btnAlteraMateria, btnCancela);
		
		Rectangle r = new Rectangle(0, 0, 2000, 2000);
		r.setFill(Color.TRANSPARENT);
		
		painel.getChildren().addAll(r, painelFundo);
		
	}
	
	private boolean atualizarMateria(int codigoMateria, String novoNome){
		boolean resultado = false;
		
		try {
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLSemRetorno("UPDATE Materia SET nome = '" + novoNome + "' WHERE codigo = " + codigoMateria + ";");
			
			resultado = true;
			
			Controlador.bd.desconectar();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
}
