package leandrosoft.dialogos;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import leandrosoft.ferramentas.Controlador;
import leandrosoft.secoes.SecaoConsultaAlunoEtapa2;
import leandrosoft.telas.MenuPrincipal;

public class CaixaAlteracaoAluno {

	public AnchorPane painel, painelFundo;
	
	private int codigoAluno;
	private int codigoTurmaInicial;
	private String nomeTurmaInicial;
	
	private TextField txtNomeAluno, txtFrequencia;
	private ObservableList<String> listaDeTurmas;
	private ComboBox<String> caixaSelecaoTurma;
	private Button btnMaisFrequencia, btnMenosFrequencia, btnAlterar, btnCancela;
	private TextArea txtaObservacao;
	
	public CaixaAlteracaoAluno(int codigoAlunoParam, int codigoTurmaParam, String nomeTurmaParam) {
	
		this.codigoAluno = codigoAlunoParam;
		this.codigoTurmaInicial = codigoTurmaParam;
		this.nomeTurmaInicial = nomeTurmaParam;
		
		painel = new AnchorPane();
		
		painelFundo = new AnchorPane();
		
		ImageView imgFundo = new ImageView(getClass().getResource("../img/altAluno.png").toString());
		
		painelFundo.getChildren().add(imgFundo);

		Label lblNomeAluno = new Label("Nome:");
		lblNomeAluno.setStyle("-fx-font-size: 20px;");
		lblNomeAluno.setLayoutX(10);
		lblNomeAluno.setLayoutY(100);
		
		txtNomeAluno = new TextField();
		txtNomeAluno.setStyle("-fx-font-size: 15px;");
		txtNomeAluno.setLayoutX(80);
		txtNomeAluno.setLayoutY(100);
		txtNomeAluno.setPrefWidth(550);
		
		Label lblNomeTurma = new Label("Turma:");
		lblNomeTurma.setStyle("-fx-font-size: 20px;");
		lblNomeTurma.setLayoutX(10);
		lblNomeTurma.setLayoutY(150);
		
		listaDeTurmas = FXCollections.observableArrayList();
		
		caixaSelecaoTurma = new ComboBox<String>();
		caixaSelecaoTurma.setItems(listaDeTurmas);
		caixaSelecaoTurma.setStyle("-fx-font-size: 15px;");
		caixaSelecaoTurma.getSelectionModel().select(0);
		caixaSelecaoTurma.setLayoutX(80);
		caixaSelecaoTurma.setLayoutY(150);
		
		Label lblFrequencia = new Label("Frequ�ncia:");
		lblFrequencia.setStyle("-fx-font-size: 20px;");
		lblFrequencia.setLayoutX(10);
		lblFrequencia.setLayoutY(200);
		
		btnMaisFrequencia = new Button("+");
		btnMaisFrequencia.setStyle("-fx-font-size: 15px;");
		btnMaisFrequencia.setLayoutX(120);
		btnMaisFrequencia.setLayoutY(200);
		
		btnMaisFrequencia.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				int frequenciaAtual = Integer.parseInt(txtFrequencia.getText().toString());
				frequenciaAtual += 1;

				txtFrequencia.setText(Integer.toString(frequenciaAtual));
			}
		});
		
		txtFrequencia = new TextField();
		txtFrequencia.setStyle("-fx-font-size: 15px; -fx-font-weight: bold;");
		txtFrequencia.setLayoutX(160);
		txtFrequencia.setLayoutY(200);
		txtFrequencia.setPrefWidth(50);
		txtFrequencia.setDisable(true);
		
		btnMenosFrequencia = new Button("-");
		btnMenosFrequencia.setStyle("-fx-font-size: 15px;");
		btnMenosFrequencia.setLayoutX(220);
		btnMenosFrequencia.setLayoutY(200);
		btnMenosFrequencia.setPrefWidth(30);
		
		btnMenosFrequencia.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				int frequenciaAtual = Integer.parseInt(txtFrequencia.getText().toString());
				
				if(frequenciaAtual > 0){
					frequenciaAtual -= 1;
				}

				txtFrequencia.setText(Integer.toString(frequenciaAtual));
			}
		});
		
		Label lblObservacao = new Label("Observa��o:");
		lblObservacao.setStyle("-fx-font-size: 20px;");
		lblObservacao.setLayoutX(10);
		lblObservacao.setLayoutY(250);
		
		txtaObservacao = new TextArea();
		txtaObservacao.setWrapText(true);
		txtaObservacao.setStyle("-fx-font-size: 15px;");
		txtaObservacao.setPrefSize(500, 100);
		txtaObservacao.setLayoutX(130);
		txtaObservacao.setLayoutY(250);
		
		btnAlterar = new Button("Alterar");
		btnAlterar.setStyle("-fx-font-size: 20px;");
		btnAlterar.setLayoutX(420);
		btnAlterar.setLayoutY(380);
		
		btnAlterar.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				
				if(txtNomeAluno.getText().toString().trim().isEmpty()){
					txtNomeAluno.requestFocus();
					Controlador.mostrarNotificacao(MenuPrincipal.painel, 1, "Preencha o campo nome.");
				}
				else if(txtNomeAluno.getText().toString().length() > 60){
					txtNomeAluno.requestFocus();
					Controlador.mostrarNotificacao(MenuPrincipal.painel, 1, "O limite do nome do aluno � de 60 caracteres.");
				}
				else if(txtaObservacao.getText().toString().length() > 200){
					txtaObservacao.requestFocus();
					Controlador.mostrarNotificacao(MenuPrincipal.painel, 1, "O limite da observa��o � de 200 caracteres.");
				}
				else{
					
					String nome = txtNomeAluno.getText().toString();
					
					String turmaSelecionada = caixaSelecaoTurma.getSelectionModel().getSelectedItem().toString();
					String[] divisor = turmaSelecionada.split(" - ");
					int codigoTurma = Integer.parseInt(divisor[0]);
					
					int frequencia = Integer.parseInt(txtFrequencia.getText().toString());
					
					String observacao = txtaObservacao.getText().toString();
					
					//Update
					if(atualizarAluno(codigoAluno, nome, frequencia, observacao, codigoTurma)){
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 0, "Aluno atualizado.");
						
						SecaoConsultaAlunoEtapa2 conAluno2 = new SecaoConsultaAlunoEtapa2(codigoTurmaInicial, nomeTurmaInicial);
						MenuPrincipal.filho.getChildren().clear();
						MenuPrincipal.filho.getChildren().addAll(conAluno2.listaDeElementos);
						
					}
					else{
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
					}
					
				}
				
			}
		});
		
		btnCancela = new Button("Cancelar");
		btnCancela.setStyle("-fx-font-size: 20px;");
		btnCancela.setLayoutX(528);
		btnCancela.setLayoutY(380);
		
		btnCancela.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				SecaoConsultaAlunoEtapa2 conAluno2 = new SecaoConsultaAlunoEtapa2(codigoTurmaInicial, nomeTurmaInicial);
				MenuPrincipal.filho.getChildren().clear();
				MenuPrincipal.filho.getChildren().addAll(conAluno2.listaDeElementos);
			}
		});
		
		if(preencherListaTurma()){
			
			if(!preencherCampos()){
				Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
				painelFundo.setDisable(true);
			}
			
		}
		else{
			painelFundo.setDisable(true);
			Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
		}
		
		painelFundo.getChildren().addAll(lblNomeAluno, txtNomeAluno, lblNomeTurma, caixaSelecaoTurma, lblFrequencia, 
				txtFrequencia, btnMaisFrequencia, btnMenosFrequencia, lblObservacao, txtaObservacao, 
				btnCancela, btnAlterar);
		
		Rectangle r = new Rectangle(0, 0, 2000, 2000);
		r.setFill(Color.TRANSPARENT);
		
		painel.getChildren().addAll(r, painelFundo);
		
	}
	
	private boolean preencherListaTurma(){
		boolean resultado = false;
		
		listaDeTurmas.clear();
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT * FROM Turma");
			
			while(Controlador.bd.recuperarResultados().next()){
				int codigo = Controlador.bd.recuperarResultados().getInt("codigo");
				String nome = Controlador.bd.recuperarResultados().getString("nome");
				
				String linha = codigo + " - " + nome;
				
				listaDeTurmas.add(linha);
			}
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
	private boolean preencherCampos(){
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT A.nome, A.frequencia, A.observacao, T.codigo, T.nome FROM Aluno AS A INNER JOIN Turma AS T ON A.codigoTurma = T.codigo WHERE A.codigo = " + codigoAluno + ";");

			if(Controlador.bd.recuperarResultados().next()){

				String nomeRecuperado = Controlador.bd.recuperarResultados().getString("A.nome");
				int frequenciaRecuperada = Controlador.bd.recuperarResultados().getInt("A.frequencia");
				String observacaoRecuperada = Controlador.bd.recuperarResultados().getString("A.observacao");
				
				int codigoTurmaRecuperado = Controlador.bd.recuperarResultados().getInt("T.codigo");
				String nomeTurmaRecuperado = Controlador.bd.recuperarResultados().getString("T.nome");
				String linha = codigoTurmaRecuperado + " - " + nomeTurmaRecuperado;
				
				txtNomeAluno.setText(nomeRecuperado);
				txtFrequencia.setText(Integer.toString(frequenciaRecuperada));
				txtaObservacao.setText(observacaoRecuperada);
				caixaSelecaoTurma.getSelectionModel().select(linha);
				
				resultado = true;
			}
			
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
	private boolean atualizarAluno(int codigoAluno, String nome, int frequencia, String observacao, int codigoTurma){
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLSemRetorno("UPDATE Aluno SET nome = '" + nome + "', frequencia = " + frequencia + ", observacao = '" + observacao + "', codigoTurma = " + codigoTurma + " WHERE codigo = " + codigoAluno + ";");
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
}
