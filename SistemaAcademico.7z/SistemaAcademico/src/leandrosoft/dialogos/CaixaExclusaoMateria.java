package leandrosoft.dialogos;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import leandrosoft.ferramentas.Controlador;
import leandrosoft.telas.MenuPrincipal;

public class CaixaExclusaoMateria {

	public AnchorPane painel, painelFundo;
	
	private int codigoMateria;
	
	public CaixaExclusaoMateria(int codigoMateriaParam) {
	
		this.codigoMateria = codigoMateriaParam;
		
		ImageView imgFundo = new ImageView(getClass().getResource("../img/dialogoExcluiMateria.png").toString());
		
		painel = new AnchorPane();
		
		painelFundo = new AnchorPane();
		painelFundo.setLayoutX(150);
		painelFundo.setLayoutY(200);
		
		Label lblAviso = new Label();
		lblAviso.setLayoutX(50);
		lblAviso.setLayoutY(90);
		lblAviso.setStyle("-fx-font-size: 16px;");
		
		if(recuperaQuantidadeStatusMateria(codigoMateria) > 0){
			lblAviso.setText("H� status cadastrados com esta mat�ria.\nExcluir mesmo assim?");
		}
		else{
			lblAviso.setText("Excluir mesmo essa mat�ria?");
		}
		
		Button btnExcluir = new Button("Excluir");
		btnExcluir.setStyle("-fx-font-size: 20px;");
		btnExcluir.setLayoutX(50);
		btnExcluir.setLayoutY(150);
		
		btnExcluir.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				
				//Validar se h� status cadastrados nessa mat�ria antes de excluir!!!
				if(recuperaQuantidadeStatusMateria(codigoMateria) > 0){
					
					if(excluirMateriasStatus(codigoMateria) && excluirMateria(codigoMateria)){
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 0, "Mat�ria exclu�da.");
						MenuPrincipal.filho.mudarSecao("conMateria");
					}
					else{
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
					}
					
				}
				else{
					
					if(excluirMateria(codigoMateria)){
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 0, "Mat�ria exclu�da.");
						MenuPrincipal.filho.mudarSecao("conMateria");
					}
					else{
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
					}
					
				}
				
			}
		});
		
		Button btnCancela = new Button("Cancelar");
		btnCancela.setStyle("-fx-font-size: 20px;");
		btnCancela.setLayoutX(246);
		btnCancela.setLayoutY(150);
		
		btnCancela.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				MenuPrincipal.filho.getChildren().remove(CaixaExclusaoMateria.this.painel);
			}
		});
		
		painelFundo.getChildren().addAll(imgFundo, lblAviso, btnExcluir, btnCancela);
		
		Rectangle r = new Rectangle(0, 0, 2000, 2000);
		r.setFill(Color.TRANSPARENT);
		
		painel.getChildren().addAll(r, painelFundo);
		
	}
	
	private boolean excluirMateria(int codigoMateria){
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLSemRetorno("DELETE FROM Materia WHERE codigo = " + codigoMateria + ".");
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
	private int recuperaQuantidadeStatusMateria(int codigoMateria){
		int quantidade = 0;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT count(codigo) AS qtdeMateria FROM Situacao WHERE codigoMateria = " + codigoMateria + ";");
			Controlador.bd.recuperarResultados().next();
			
			quantidade = Controlador.bd.recuperarResultados().getInt("qtdeMateria");
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return quantidade;
	}
	
	private boolean excluirMateriasStatus(int codigoMateria){
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLSemRetorno("DELETE FROM Situacao WHERE codigoMateria = " + codigoMateria + ";");
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
}
