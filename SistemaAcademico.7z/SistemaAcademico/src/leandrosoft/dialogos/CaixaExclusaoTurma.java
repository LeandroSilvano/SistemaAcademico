package leandrosoft.dialogos;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import leandrosoft.ferramentas.Controlador;
import leandrosoft.telas.MenuPrincipal;

public class CaixaExclusaoTurma {

	public AnchorPane painel, painelFundo;
	
	private int codigoTurma;
	
	public CaixaExclusaoTurma(int codigoTurmaParam, String nomeTurmaParam) {
		
		this.codigoTurma = codigoTurmaParam;
		
		painel = new AnchorPane();
		
		painelFundo = new AnchorPane();
		painelFundo.setLayoutX(150);
		painelFundo.setLayoutY(200);
		
		ImageView imgFundo = new ImageView(getClass().getResource("../img/dialogoExcluiTurma.png").toString());
		
		Button btnExcluir = new Button("Excluir");
		btnExcluir.setStyle("-fx-font-size: 20px;");
		btnExcluir.setLayoutX(50);
		btnExcluir.setLayoutY(150);
		
		btnExcluir.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				
				if(recuperaQuantidadeAlunosTurma() > 0){
					
					if(excluirAlunosTurma() && excluirTurma()){
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 0, "Turma exclu�da.");
						MenuPrincipal.filho.mudarSecao("conTurma");
					}
					else{
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
					}
					
				}
				else{
					
					if(excluirTurma()){
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 0, "Turma exclu�da.");
						MenuPrincipal.filho.mudarSecao("conTurma");
					}
					else{
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
					}
					
				}
				
			}
		});
		
		Button btnCancela = new Button("Cancelar");
		btnCancela.setStyle("-fx-font-size: 20px;");
		btnCancela.setLayoutX(246);
		btnCancela.setLayoutY(150);
		
		btnCancela.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				MenuPrincipal.filho.mudarSecao("conTurma");
			}
		});
		
		Label lblAviso = new Label();
		lblAviso.setLayoutX(30);
		lblAviso.setLayoutY(85);
		lblAviso.setStyle("-fx-font-size: 16px;");
		
		if(recuperaQuantidadeAlunosTurma() > 0){
			lblAviso.setText("H� alunos na turma '" + nomeTurmaParam + "',\nExcluir assim mesmo?");
		}
		else{
			lblAviso.setText("Excluir a turma '" + nomeTurmaParam + "' ?");
		}
		
		painelFundo.getChildren().addAll(imgFundo, btnExcluir, btnCancela, lblAviso);
		
		Rectangle r = new Rectangle(0, 0, 2000, 2000);
		r.setFill(Color.TRANSPARENT);

		painel.getChildren().addAll(r, painelFundo);
		
	}
	
	private int recuperaQuantidadeAlunosTurma(){
		int quantidade = 0;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT count(codigo) AS qtdeAluno FROM Aluno WHERE codigoTurma = " + codigoTurma + ";");
			Controlador.bd.recuperarResultados().next();
			
			quantidade = Controlador.bd.recuperarResultados().getInt("qtdeAluno");
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return quantidade;
	}
	
	private boolean excluirAlunosTurma(){
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLSemRetorno("DELETE FROM Aluno WHERE codigoTurma = " + codigoTurma + ";");
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
	private boolean excluirTurma(){
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLSemRetorno("DELETE FROM Turma WHERE codigo = " + codigoTurma + ";");
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		
		return resultado;
	}
	
}
