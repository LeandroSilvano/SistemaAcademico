package leandrosoft.ferramentas;

import javafx.animation.AnimationTimer;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

public class Notificacao extends AnchorPane {

	private ImageView imgFundo;

	public long tempoInicial, tempoAtual, tempoPassado;
	private double opacidade = 0;
	
	
	
	public Notificacao(int codigo, String mensagem) {

		/*
		 * Codigos de Notificacao: 0 - Confirma 1 - Aviso 2 - Erro
		 */

		imgFundo = new ImageView();

		switch (codigo) {
		case 0:
			imgFundo.setImage(new Image(getClass().getResource(
					"../img/notificacao_confirma.png").toString()));
			break;
		case 1:
			imgFundo.setImage(new Image(getClass().getResource(
					"../img/notificacao_aviso.png").toString()));
			break;
		case 2:
			imgFundo.setImage(new Image(getClass().getResource(
					"../img/notificacao_erro.png").toString()));
			break;
		}

		Label lblMensagem = new Label(mensagem);
		lblMensagem
				.setStyle("-fx-font-weight: bold; -fx-text-fill: #FFFFFF; -fx-font-size: 12px;");
		lblMensagem.setLayoutX(15);
		lblMensagem.setLayoutY(15);
		
		this.setLayoutX(700);
		this.setLayoutY(70);

		this.getChildren().addAll(imgFundo, lblMensagem);

		this.setOpacity(opacidade);

		// Sincronizando tempo para iniciar / esconder a notificacao
		// automaticamente
		 tempoInicial = System.currentTimeMillis();

		AnimationTimer temporizador = new AnimationTimer() {

			@Override
			public void handle(long arg0) {

				tempoAtual = System.currentTimeMillis();

				tempoPassado = tempoAtual - tempoInicial;

				if(tempoPassado < 2000){
					opacidade = (double) tempoPassado / 1000;
				}
				else if(tempoPassado > 4000){
					opacidade -= 0.05;
				}
				
				Notificacao.this.setOpacity(opacidade);
			}
		};

		temporizador.start();

	}

}
