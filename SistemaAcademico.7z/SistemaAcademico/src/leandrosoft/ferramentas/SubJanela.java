package leandrosoft.ferramentas;

import javafx.animation.AnimationTimer;
import javafx.scene.layout.AnchorPane;
import leandrosoft.secoes.SecaoCadastroAluno;
import leandrosoft.secoes.SecaoCadastroMateria;
import leandrosoft.secoes.SecaoCadastroStatusEtapa1;
import leandrosoft.secoes.SecaoCadastroTurma;
import leandrosoft.secoes.SecaoConsultaAlunoEtapa1;
import leandrosoft.secoes.SecaoConsultaMateria;
import leandrosoft.secoes.SecaoConsultaStatusEtapa1;
import leandrosoft.secoes.SecaoConsultaTurma;

public class SubJanela extends AnchorPane{

	private long tempoInicial;
	private long tempoAtual;
	private long tempoPassado;
	
	private double tempoDeEspera = 1000;
	
	public void mudarSecao(String nomeSecao){
		
		mostrar();
		
		//Limpando painel para colocar novos itens a cada mudanca
		this.getChildren().clear();

		switch(nomeSecao){
		
		case "cadTurma":
			SecaoCadastroTurma cadTurma = new SecaoCadastroTurma();
			this.getChildren().addAll(cadTurma.listaDeElementos);
			break;
			
		case "cadAluno":
			SecaoCadastroAluno cadAluno = new SecaoCadastroAluno();
			this.getChildren().addAll(cadAluno.listaDeElementos);
			break;
			
		case "cadMateria":
			SecaoCadastroMateria cadMateria = new SecaoCadastroMateria();
			this.getChildren().addAll(cadMateria.listaDeElementos);
			break;
			
		case "cadStatus":
			SecaoCadastroStatusEtapa1 cadStatus = new SecaoCadastroStatusEtapa1();
			this.getChildren().addAll(cadStatus.listaDeElementos);
			break;
			
		case "conTurma":
			SecaoConsultaTurma conturma = new SecaoConsultaTurma();
			this.getChildren().addAll(conturma.listaDeElementos);
			break;
			
		case "conAluno":
			SecaoConsultaAlunoEtapa1 conAluno = new SecaoConsultaAlunoEtapa1();
			this.getChildren().addAll(conAluno.listaDeElementos);
			break;
			
		case "conMateria":
			SecaoConsultaMateria conMateria = new SecaoConsultaMateria();
			this.getChildren().addAll(conMateria.listaDeElementos);
			break;
			
		case "conStatus":
			SecaoConsultaStatusEtapa1 conStatus1 = new SecaoConsultaStatusEtapa1();
			this.getChildren().addAll(conStatus1.listaDeElementos);
			break;
			
		}
		
	}
	
	private void mostrar(){
		tempoInicial = System.currentTimeMillis();
		tempoAtual = 0;
		tempoPassado = 0;
		
		SubJanela.this.setOpacity(0);
		
		AnimationTimer timer = new AnimationTimer() {
			
			@Override
			public void handle(long arg0) {
				tempoAtual = System.currentTimeMillis();
				tempoPassado = tempoAtual - tempoInicial;

				if(tempoPassado <= tempoDeEspera){
					SubJanela.this.setOpacity((double)tempoPassado / tempoDeEspera);
				}
				else{
					this.stop();
				}
			
			}
		};
		
		timer.start();
	}
	
}
