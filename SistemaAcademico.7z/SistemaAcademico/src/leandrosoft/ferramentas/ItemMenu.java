package leandrosoft.ferramentas;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import leandrosoft.telas.MenuPrincipal;

public class ItemMenu extends Rectangle{

	private String nome;
	
	public ItemMenu(double x, double y, double w, double h, String nome) {

		this.nome = nome;
		
		this.setX(x);
		this.setY(y);
		this.setWidth(w);
		this.setHeight(h);
		this.setOpacity(0);
		this.setFill(Color.WHITE);
		
		this.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent me){
				ItemMenu.this.setOpacity(0.2);
			}
		});
		
		this.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent me){
				ItemMenu.this.setOpacity(0);
			}
		});
		
		this.setOnMouseClicked(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent me){
				
				//Dependendo do nome do ItemMenu que for clicado, deve-se abrir uma janela /comportamento diferente
				
				switch(ItemMenu.this.nome){
				case "fecha":
					System.exit(0);
					break;
					
				case "minimiza":
					MenuPrincipal.estaMinimizado = true;
					break;
					
				case "cadTurma":
					MenuPrincipal.filho.mudarSecao("cadTurma");
					break;
					
				case "cadAluno":
					MenuPrincipal.filho.mudarSecao("cadAluno");
					break;
					
				case "cadMateria":
					MenuPrincipal.filho.mudarSecao("cadMateria");
					break;
					
				case "cadStatus":
					MenuPrincipal.filho.mudarSecao("cadStatus");
					break;
					
				case "conTurma":
					MenuPrincipal.filho.mudarSecao("conTurma");
					break;
					
				case "conAluno":
					MenuPrincipal.filho.mudarSecao("conAluno");
					break;
					
				case "conMateria":
					MenuPrincipal.filho.mudarSecao("conMateria");
					break;
					
				case "conStatus":
					MenuPrincipal.filho.mudarSecao("conStatus");
					break;
				}
				
			}
		});
		
	}
	
}
