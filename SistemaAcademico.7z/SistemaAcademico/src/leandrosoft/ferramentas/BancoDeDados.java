package leandrosoft.ferramentas;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class BancoDeDados {

	public ResultSet resultado;

	public Connection conexao;

	public boolean conectar() {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			   String url = "jdbc:mysql://localhost/SistemaAcademico";
	           Class.forName ("com.mysql.jdbc.Driver");
	           this.conexao = DriverManager.getConnection (url,"admin","p0o9i8u7");
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public boolean desconectar(){
		try {
			this.conexao.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean executarSQLComRetorno(String sql){
		
		try {
			Statement sentenca = this.conexao.createStatement();
			sentenca.execute(sql);
			
			this.resultado = sentenca.getResultSet();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean executarSQLSemRetorno(String sql){
		
		try {
			Statement sentenca = this.conexao.createStatement();
			sentenca.execute(sql);
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public ResultSet recuperarResultados(){
		return this.resultado;
	}
}
