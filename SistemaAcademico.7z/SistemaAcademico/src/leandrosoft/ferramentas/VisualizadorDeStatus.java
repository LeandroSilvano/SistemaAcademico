package leandrosoft.ferramentas;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;

public class VisualizadorDeStatus extends AnchorPane{

	private ObservableList<String> listaDeStatus; //Aprovado / Reprovado
	
	public int codigoStatus;
	public String estado;
	
	public Label lblInfo;
	public ComboBox<String> caixaSelecaoStatus;
	
	public <T> VisualizadorDeStatus(int codigoStatus, int codigoMateria, String nomeMateria, String statusMateria) {

		this.codigoStatus = codigoStatus;
		
		listaDeStatus = FXCollections.observableArrayList();
		listaDeStatus.addAll("Aprovado", "Reprovado");
		
		lblInfo = new Label(codigoMateria + " - " +nomeMateria);
		lblInfo.setStyle("-fx-font-size: 20px;");
		
		ComboBox<String> caixaSelecaoStatus = new ComboBox<String>();
		caixaSelecaoStatus.setItems(listaDeStatus);
		caixaSelecaoStatus.setStyle("-fx-font-size: 20px;");
		caixaSelecaoStatus.getSelectionModel().select(statusMateria);
		caixaSelecaoStatus.setLayoutX(500);
		
		caixaSelecaoStatus.valueProperty().addListener(new ChangeListener<String>() {

			@Override
			public void changed(ObservableValue<? extends String> arg0, String arg1, String arg2) {
				VisualizadorDeStatus.this.estado = caixaSelecaoStatus.getSelectionModel().getSelectedItem().toString();
			}
		});
		
		this.estado = caixaSelecaoStatus.getSelectionModel().getSelectedItem().toString();
		
		this.getChildren().addAll(lblInfo, caixaSelecaoStatus);
		
	}
	
}
