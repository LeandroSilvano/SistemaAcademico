package leandrosoft.ferramentas;

import javafx.scene.layout.AnchorPane;


public class Controlador {

	public static BancoDeDados bd = new BancoDeDados();
	
	public Controlador() {
		bd = new BancoDeDados();
	}
	
	public static void mostrarNotificacao(AnchorPane painelAserMostrado, int codigoNotificacao, String mensagemNotificacao){
		Notificacao not = new Notificacao(codigoNotificacao, mensagemNotificacao);
		painelAserMostrado.getChildren().add(not);
	}
	
}
