package leandrosoft.main;

import javafx.application.Application;
import javafx.stage.Stage;
import leandrosoft.telas.Splash;

public class Principal extends Application{

	@Override
	public void start(Stage palcoPrimario) throws Exception {

		new Splash();
	}
	
	public static void main(String[] args) {
		launch();
	}
	
}
