package leandrosoft.secoes;

import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import leandrosoft.ferramentas.Controlador;
import leandrosoft.telas.MenuPrincipal;

public class SecaoConsultaStatusEtapa2 {

	public ArrayList<Node> listaDeElementos;
	
	private ObservableList<String> listaDeAluno;
	
	private int codigoTurma;
	private String nomeTurma;
	
	public SecaoConsultaStatusEtapa2(int codigoTurmaParam, String nomeDaTurmaParam) {
		
		this.codigoTurma = codigoTurmaParam;
		this.nomeTurma = nomeDaTurmaParam;
		
		listaDeElementos = new ArrayList<Node>();
		
		listaDeAluno = FXCollections.observableArrayList();
		
		ImageView imgFundo = new ImageView(getClass().getResource("../img/conStatus.png").toString());
		
		listaDeElementos.add(imgFundo);
		
		if(recuperarQuantidadeAlunosTurma(codigoTurma) == 0){
			Label lblFaltaAluno = new Label("Essa turma n�o possui aluno.");
			lblFaltaAluno.setStyle("-fx-font-size: 20px;");
			lblFaltaAluno.setLayoutX(150);
			lblFaltaAluno.setLayoutY(200);
			listaDeElementos.add(lblFaltaAluno);
			
			Button btnVoltar = new Button("Voltar");
			btnVoltar.setStyle("-fx-font-size: 20px;");
			btnVoltar.setLayoutX(430);
			btnVoltar.setLayoutY(185);
			
			btnVoltar.setOnAction(new EventHandler<ActionEvent>() {
				
				@Override
				public void handle(ActionEvent arg0) {
					MenuPrincipal.filho.mudarSecao("conStatus");
				}
			});
			
			listaDeElementos.add(btnVoltar);
		}
		else if(!recuperarAlunosTurmaQueTemStatus(codigoTurma)){
			Label lblFaltaAluno = new Label("Nenhum aluno dessa turma possui status para consulta.");
			lblFaltaAluno.setStyle("-fx-font-size: 20px;");
			lblFaltaAluno.setLayoutX(150);
			lblFaltaAluno.setLayoutY(140);
			listaDeElementos.add(lblFaltaAluno);
			
			Button btnVoltar = new Button("Voltar");
			btnVoltar.setStyle("-fx-font-size: 20px;");
			btnVoltar.setLayoutX(560);
			btnVoltar.setLayoutY(185);
			
			btnVoltar.setOnAction(new EventHandler<ActionEvent>() {
				
				@Override
				public void handle(ActionEvent arg0) {
					MenuPrincipal.filho.mudarSecao("conStatus");
				}
			});
			
			listaDeElementos.add(btnVoltar);
		}
		else{
			Label lblNomeTurma = new Label("Turma: " + nomeTurma + " - Selecione um Aluno");
			lblNomeTurma.setStyle("-fx-font-size: 20px;");
			lblNomeTurma.setLayoutX(10);
			lblNomeTurma.setLayoutY(80);
			
			ListView<String> visualizadorDeAluno = new ListView<String>();
			visualizadorDeAluno.setItems(listaDeAluno);
			visualizadorDeAluno.setPrefSize(690, 315);
			visualizadorDeAluno.setLayoutX(10);
			visualizadorDeAluno.setLayoutY(120);
			
			if(preencherListaAluno(codigoTurma)){
				visualizadorDeAluno.getSelectionModel().select(0);
			}
			else{
				Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
			}
			
			Button btnVoltar = new Button("Voltar");
			btnVoltar.setStyle("-fx-font-size: 20px;");
			btnVoltar.setLayoutX(10);
			btnVoltar.setLayoutY(480);
			
			btnVoltar.setOnAction(new EventHandler<ActionEvent>() {
				
				@Override
				public void handle(ActionEvent arg0) {
					MenuPrincipal.filho.mudarSecao("conStatus");
				}
			});
			
			Button btnProceder = new Button("Proceder");
			btnProceder.setStyle("-fx-font-size: 20px;");
			btnProceder.setLayoutX(595);
			btnProceder.setLayoutY(450);
			
			btnProceder.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent e){
					String selecao = visualizadorDeAluno.getSelectionModel().getSelectedItem();
					String[] divisor = selecao.split(" - ");
					
					int codigoAlunoSelecionado = Integer.parseInt(divisor[0]);
					String nomeAlunoSelecionado = divisor[1];
					
					MenuPrincipal.filho.getChildren().clear();
					
					SecaoConsultaStatusEtapa3 conStatus3 = new SecaoConsultaStatusEtapa3(codigoAlunoSelecionado, nomeAlunoSelecionado, codigoTurma, nomeTurma);
					MenuPrincipal.filho.getChildren().addAll(conStatus3.listaDeElementos);
					
				}
			});
			
			listaDeElementos.add(lblNomeTurma);
			listaDeElementos.add(visualizadorDeAluno);
			listaDeElementos.add(btnVoltar);
			listaDeElementos.add(btnProceder);
			
		}
		
	}

	private int recuperarQuantidadeAlunosTurma(int codigoDaTurma){
		int resultado = 0;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT count(codigo) AS qtdeAluno FROM Aluno WHERE codigoTurma = " + codigoDaTurma + ";");
			Controlador.bd.recuperarResultados().next();
			
			resultado = Controlador.bd.recuperarResultados().getInt("qtdeAluno");
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
	private boolean recuperarAlunosTurmaQueTemStatus(int codigoTurma){
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT T.nome, A.nome, M.nome, S.estado FROM Situacao AS S INNER JOIN Aluno AS A ON S.codigoAluno = A.codigo INNER JOIN Materia AS M ON S.codigoMateria = M.codigo INNER JOIN Turma AS T ON A.codigoTurma = T.codigo WHERE T.codigo = " + codigoTurma + ";");
			
			if(Controlador.bd.recuperarResultados().next()){
				resultado = true;
			}
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
	private boolean preencherListaAluno(int codigoDaTurma){
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT DISTINCT A.codigo, A.nome FROM Aluno AS A INNER JOIN Situacao AS S ON S.codigoAluno = A.codigo INNER JOIN Turma AS T ON T.codigo = A.codigoTurma WHERE T.codigo = " + codigoDaTurma + " ORDER BY A.nome;");
			
			while(Controlador.bd.recuperarResultados().next()){
				long codigo = Controlador.bd.recuperarResultados().getLong("A.codigo");
				String nome = Controlador.bd.recuperarResultados().getString("A.nome");
				
				String linha = codigo + " - " + nome;
				
				listaDeAluno.add(linha);
			}
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
}
