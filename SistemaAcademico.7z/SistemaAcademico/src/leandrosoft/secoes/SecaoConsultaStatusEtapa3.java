package leandrosoft.secoes;

import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import leandrosoft.ferramentas.Controlador;
import leandrosoft.ferramentas.VisualizadorDeStatus;
import leandrosoft.telas.MenuPrincipal;

public class SecaoConsultaStatusEtapa3 {

	public ArrayList<Node> listaDeElementos;
	
	private ObservableList<VisualizadorDeStatus> listaDeStatus;
	
	public SecaoConsultaStatusEtapa3(int codigoAlunoParam, String nomeAlunoParam, int codigoTurmaParam, String nomeTurmaParam) {

		listaDeElementos = new ArrayList<Node>();
		
		listaDeStatus = FXCollections.observableArrayList();
		
		ImageView imgFundo = new ImageView(getClass().getResource("../img/conStatus.png").toString());
		
		listaDeElementos.add(imgFundo);
		
		Label lblNomeAluno = new Label("Aluno: " + nomeAlunoParam);
		lblNomeAluno.setStyle("-fx-font-size: 20px;");
		lblNomeAluno.setLayoutX(10);
		lblNomeAluno.setLayoutY(80);
		
		ListView<VisualizadorDeStatus> visualizadorDeListaDeStatus = new ListView<VisualizadorDeStatus>();
		visualizadorDeListaDeStatus.setItems(listaDeStatus);
		visualizadorDeListaDeStatus.setPrefSize(690, 315);
		visualizadorDeListaDeStatus.setLayoutX(10);
		visualizadorDeListaDeStatus.setLayoutY(120);
		
		Button btnAlteraStatus = new Button("Alterar status listados");
		btnAlteraStatus.setStyle("-fx-font-size: 20px;");
		btnAlteraStatus.setLayoutX(380);
		btnAlteraStatus.setLayoutY(450);
		btnAlteraStatus.setDisable(true);
		
		btnAlteraStatus.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				if(atualizarStatusListados()){
					if(preencherStatusAluno(codigoAlunoParam)){
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 0, "Status listados alterados.");
					}
					else{
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
					}
				}
				else{
					Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
				}
			}
			
		});
		
		Button btnExcluiStatus = new Button("Excluir");
		btnExcluiStatus.setStyle("-fx-font-size: 20px;");
		btnExcluiStatus.setLayoutX(615);
		btnExcluiStatus.setLayoutY(450);
		btnExcluiStatus.setDisable(true);
		
		btnExcluiStatus.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				
				String statusSelecionado = visualizadorDeListaDeStatus.getSelectionModel().getSelectedItem().lblInfo.getText();
				String[] divisor = statusSelecionado.split(" - ");
				int codigoMateriaSelecionada = Integer.parseInt(divisor[0]);
				
				if(excluirStatus(codigoAlunoParam, codigoMateriaSelecionada)){
					Controlador.mostrarNotificacao(MenuPrincipal.painel, 0, "Status exclu�do.");
					
					if(recuperarQuantidadeStatusAluno(codigoAlunoParam) > 0){
						if(preencherStatusAluno(codigoAlunoParam)){
							visualizadorDeListaDeStatus.getSelectionModel().select(0);
						}
						else{
							Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
						}
					}
					else{
						SecaoConsultaStatusEtapa2 conStatus2 = new SecaoConsultaStatusEtapa2(codigoTurmaParam, nomeTurmaParam);
						MenuPrincipal.filho.getChildren().clear();
						MenuPrincipal.filho.getChildren().addAll(conStatus2.listaDeElementos);
					}
					
				}
				else{
					Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
				}
				
			}
		});
		
		if(preencherStatusAluno(codigoAlunoParam)){
			visualizadorDeListaDeStatus.getSelectionModel().select(0);
			btnAlteraStatus.setDisable(false);
			btnExcluiStatus.setDisable(false);
		}
		else{
			Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
		}
		
		listaDeElementos.add(lblNomeAluno);
		listaDeElementos.add(visualizadorDeListaDeStatus);
		listaDeElementos.add(btnAlteraStatus);
		listaDeElementos.add(btnExcluiStatus);
		
	}
	
	private boolean preencherStatusAluno(int codigoAluno){
		boolean resultado = false;
		
		listaDeStatus.clear();
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT M.codigo, M.nome, S.codigo, S.estado FROM Materia AS M INNER JOIN Situacao AS S ON S.codigoMateria = M.codigo WHERE S.codigoAluno = " + codigoAluno + " ORDER BY M.nome;");
			
			while(Controlador.bd.recuperarResultados().next()){
				
				int codigoStatus = Controlador.bd.recuperarResultados().getInt("S.codigo");
				
				int codigoMateria = Controlador.bd.recuperarResultados().getInt("M.codigo");
				
				String nome = Controlador.bd.recuperarResultados().getString("M.nome");
				
				String estado = Controlador.bd.recuperarResultados().getString("S.estado");
				
				VisualizadorDeStatus vs = new VisualizadorDeStatus(codigoStatus, codigoMateria, nome, estado);
				
				listaDeStatus.add(vs);
				
			}
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
	private boolean excluirStatus(int codigoAluno, int codigoMateria){
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLSemRetorno("DELETE FROM Situacao WHERE codigoAluno = " + codigoAluno + " and codigoMateria = " + codigoMateria + ";");
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
	private int recuperarQuantidadeStatusAluno(int codigoAluno){
		int quantidade = 0;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT count(codigo) AS qtdeStatus FROM Situacao WHERE codigoAluno = " + codigoAluno + ";");
			Controlador.bd.recuperarResultados().next();
			
			quantidade = Controlador.bd.recuperarResultados().getInt("qtdeStatus");
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return quantidade;
	}
	
	private boolean atualizarStatusListados(){
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			for (VisualizadorDeStatus x : listaDeStatus) {
				Controlador.bd.executarSQLSemRetorno("UPDATE Situacao SET estado = '" + x.estado + "' WHERE codigo = " + x.codigoStatus + ";");
			}
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
}
