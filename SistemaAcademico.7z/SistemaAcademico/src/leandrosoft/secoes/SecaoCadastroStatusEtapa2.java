package leandrosoft.secoes;

import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import leandrosoft.ferramentas.Controlador;
import leandrosoft.telas.MenuPrincipal;

public class SecaoCadastroStatusEtapa2 {

	public ArrayList<Node> listaDeElementos;
	
	private ObservableList<String> listaDeAluno, listaDeMateria, listaDeStatus;
	
	private int codigoTurma;
	
	public SecaoCadastroStatusEtapa2(int codigoTurmaParam, String nomeTurmaParam) {

		this.codigoTurma = codigoTurmaParam;
		
		listaDeElementos = new ArrayList<Node>();
		
		listaDeAluno = FXCollections.observableArrayList();
		listaDeMateria = FXCollections.observableArrayList();
		listaDeStatus = FXCollections.observableArrayList();
		
		ImageView imgFundo = new ImageView(getClass().getResource("../img/cadStatus.png").toString());
		
		listaDeElementos.add(imgFundo);
		
		if(recuperarQuantidadeAlunosTurma(codigoTurma) == 0){
			Label lblFaltaAluno = new Label("Essa turma n�o possui aluno.");
			lblFaltaAluno.setStyle("-fx-font-size: 20px;");
			lblFaltaAluno.setLayoutX(150);
			lblFaltaAluno.setLayoutY(200);
			listaDeElementos.add(lblFaltaAluno);
			
			Button btnVoltar = new Button("Voltar");
			btnVoltar.setStyle("-fx-font-size: 20px;");
			btnVoltar.setLayoutX(430);
			btnVoltar.setLayoutY(185);
			
			btnVoltar.setOnAction(new EventHandler<ActionEvent>() {
				
				@Override
				public void handle(ActionEvent arg0) {
					MenuPrincipal.filho.mudarSecao("cadStatus");
				}
			});
			
			listaDeElementos.add(btnVoltar);
		}
		else{
			
			Label lblNomeAluno = new Label("Turma: " + nomeTurmaParam + " - Selecione um Aluno");
			lblNomeAluno.setStyle("-fx-font-size: 20px;");
			lblNomeAluno.setLayoutX(10);
			lblNomeAluno.setLayoutY(80);
			
			ListView<String> visualizadorDeAluno = new ListView<String>();
			visualizadorDeAluno.setItems(listaDeAluno);
			visualizadorDeAluno.setPrefSize(690, 315);
			visualizadorDeAluno.setLayoutX(10);
			visualizadorDeAluno.setLayoutY(120);
			
			if(preencherListaAluno(codigoTurma)){
				visualizadorDeAluno.getSelectionModel().select(0);
			}
			else{
				Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
			}
			
			Label lblNomeMateria = new Label("Selecione a Mat�ria");
			lblNomeMateria.setStyle("-fx-font-size: 20px;");
			lblNomeMateria.setLayoutX(10);
			lblNomeMateria.setLayoutY(450);
			
			ComboBox<String> caixaSelecaoMateria = new ComboBox<String>();
			caixaSelecaoMateria.setItems(listaDeMateria);
			caixaSelecaoMateria.setStyle("-fx-font-size: 20px;");
			caixaSelecaoMateria.getSelectionModel().select(0);
			caixaSelecaoMateria.setLayoutX(10);
			caixaSelecaoMateria.setLayoutY(480);
			
			if(preencherListaMateria()){
				caixaSelecaoMateria.getSelectionModel().select(0);
			}
			else{
				Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
			}
			
			Label lblNomeStatus = new Label("Selecione o Status");
			lblNomeStatus.setStyle("-fx-font-size: 20px;");
			lblNomeStatus.setLayoutX(540);
			lblNomeStatus.setLayoutY(450);
			
			ComboBox<String> caixaSelecaoStatus = new ComboBox<String>();
			caixaSelecaoStatus.setItems(listaDeStatus);
			caixaSelecaoStatus.setStyle("-fx-font-size: 20px;");
			caixaSelecaoStatus.getSelectionModel().select(0);
			caixaSelecaoStatus.setLayoutX(540);
			caixaSelecaoStatus.setLayoutY(480);
			listaDeStatus.addAll("Aprovado", "Reprovado");
			caixaSelecaoStatus.getSelectionModel().select(0);
			
			Button btnCadastrar = new Button("Cadastrar");
			btnCadastrar.setStyle("-fx-font-size: 20px;");
			btnCadastrar.setLayoutX(590);
			btnCadastrar.setLayoutY(550);
			
			btnCadastrar.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent e){
					
					String materiaSelecionada = caixaSelecaoMateria.getSelectionModel().getSelectedItem().toString();
					String[] divisorMateria = materiaSelecionada.split(" - ");
					int codigoMateriaSelecionada = Integer.parseInt(divisorMateria[0]);

					String alunoSelecionado = visualizadorDeAluno.getSelectionModel().getSelectedItem().toString();
					String[] divisorAluno = alunoSelecionado.split(" - ");
					int codigoAlunoSelecionado = Integer.parseInt(divisorAluno[0]);
					
					String statusSelecionado = caixaSelecaoStatus.getSelectionModel().getSelectedItem().toString();
					
					if(validarCadastroDeStatus(codigoMateriaSelecionada, codigoAlunoSelecionado)){
						
						if(cadastrarStatus(codigoMateriaSelecionada, codigoAlunoSelecionado, statusSelecionado)){
							Controlador.mostrarNotificacao(MenuPrincipal.painel, 0, "Status cadastrado com sucesso.");
						}
						else{
							Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
						}
						
					}
					else{
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 1, "Esse aluno j� tem status nessa mat�ria, consulte.");
					}
					
				}
			});
			
			listaDeElementos.add(lblNomeAluno);
			listaDeElementos.add(visualizadorDeAluno);
			
			listaDeElementos.add(lblNomeMateria);
			listaDeElementos.add(caixaSelecaoMateria);
			
			listaDeElementos.add(lblNomeStatus);
			listaDeElementos.add(caixaSelecaoStatus);
			
			listaDeElementos.add(btnCadastrar);
		}
		
	}
	
	private boolean preencherListaMateria() {
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT * FROM Materia");
			
			while(Controlador.bd.recuperarResultados().next()){
				int codigo = Controlador.bd.recuperarResultados().getInt("codigo");
				String nome = Controlador.bd.recuperarResultados().getString("nome");
				
				String linha = codigo + " - " + nome;
				
				listaDeMateria.add(linha);
			}
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}

	private int recuperarQuantidadeAlunosTurma(int codigoDaTurma){
		int resultado = 0;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT count(codigo) AS qtdeAluno FROM Aluno WHERE codigoTurma = " + codigoDaTurma + ";");
			Controlador.bd.recuperarResultados().next();
			
			resultado = Controlador.bd.recuperarResultados().getInt("qtdeAluno");
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}

	private boolean preencherListaAluno(int codigoDaTurma){
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT * FROM Aluno WHERE codigoTurma = " + codigoDaTurma + ";");
			
			while(Controlador.bd.recuperarResultados().next()){
				long codigo = Controlador.bd.recuperarResultados().getLong("codigo");
				String nome = Controlador.bd.recuperarResultados().getString("nome");
				
				String linha = codigo + " - " + nome;
				
				listaDeAluno.add(linha);
			}
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
	private boolean validarCadastroDeStatus(int codigoMateria, long codigoAluno){
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT * FROM Situacao WHERE codigoMateria = " + codigoMateria + " and codigoAluno = " + codigoAluno + ";");
			
			if(!Controlador.bd.recuperarResultados().next()){
				resultado = true;
			}
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
	private boolean cadastrarStatus(int codigoDaMateria, int codigoDoAluno, String status){
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLSemRetorno("INSERT INTO Situacao (codigoMateria, codigoAluno, estado) VALUE (" + codigoDaMateria + ", " + codigoDoAluno + ", '" + status + "');");
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
}
