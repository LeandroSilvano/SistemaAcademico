package leandrosoft.secoes;

import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import leandrosoft.ferramentas.Controlador;
import leandrosoft.telas.MenuPrincipal;

public class SecaoCadastroAluno {

	public ArrayList<Node> listaDeElementos;
	
	public SecaoCadastroAluno() {

		listaDeElementos = new ArrayList<Node>();
		
		ImageView imgFundo = new ImageView(getClass().getResource("../img/cadAluno.png").toString());
		
		listaDeElementos.add(imgFundo);

		if(recuperarQuantidadeTurma() == 0){
			Label lblInfo = new Label("N�o h� turma cadastrada para a inser��o de aluno.");
			lblInfo.setStyle("-fx-font-size: 20px;");
			lblInfo.setLayoutX(150);
			lblInfo.setLayoutY(200);
			listaDeElementos.add(lblInfo);
		}
		else{
			ObservableList<String> listaDeTurmas = FXCollections.observableArrayList();
			listaDeTurmas.addAll(recuperaNomeTurma());
			
			ComboBox<String> caixaSelecaoTurma = new ComboBox<String>();
			caixaSelecaoTurma.setItems(listaDeTurmas);
			caixaSelecaoTurma.setStyle("-fx-font-size: 20px;");
			caixaSelecaoTurma.getSelectionModel().select(0);
			caixaSelecaoTurma.setLayoutX(110);
			caixaSelecaoTurma.setLayoutY(175);
			
			Label lblNomeAluno = new Label("Nome:");
			lblNomeAluno.setStyle("-fx-font-size: 30px;");
			lblNomeAluno.setLayoutX(10);
			lblNomeAluno.setLayoutY(100);
			
			TextField txtNomeAluno = new TextField();
			txtNomeAluno.setStyle("-fx-font-size: 20px;");
			txtNomeAluno.setLayoutX(110);
			txtNomeAluno.setLayoutY(100);
			txtNomeAluno.setPrefWidth(550);
			
			Label lblNomeTurma = new Label("Turma:");
			lblNomeTurma.setStyle("-fx-font-size: 30px;");
			lblNomeTurma.setLayoutX(10);
			lblNomeTurma.setLayoutY(170);
			
			Button btnCadastroAluno = new Button("Cadastrar");
			btnCadastroAluno.setStyle("-fx-font-size: 20px;");
			btnCadastroAluno.setLayoutX(550);
			btnCadastroAluno.setLayoutY(175);
			
			btnCadastroAluno.setOnAction(new EventHandler<ActionEvent>() {
				
				@Override
				public void handle(ActionEvent arg0) {
					
					if(txtNomeAluno.getText().toString().trim().isEmpty()){
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 1, "Preencha o campo 'nome'");
					}
					else if(txtNomeAluno.getText().toString().length() > 60){
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 1, "O limite do nome de aluno � de 60 caracteres.");
						txtNomeAluno.requestFocus();
					}
					
					else {
						
						String nomeAluno = txtNomeAluno.getText().toString();
						
						String turmaSelecionada = caixaSelecaoTurma.getSelectionModel().getSelectedItem().toString();
						String[] divisor = turmaSelecionada.split(" - ");
						int codigoTurmaSelecionada = Integer.parseInt(divisor[0]);
						
						if(cadastrarAluno(nomeAluno, codigoTurmaSelecionada)){
							Controlador.mostrarNotificacao(MenuPrincipal.painel, 0, "Aluno cadastrado.");
							txtNomeAluno.clear();
							txtNomeAluno.requestFocus();
						}
						else{
							Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
						}
						
					}
				}
					
			});
			
			listaDeElementos.add(lblNomeAluno);
			listaDeElementos.add(txtNomeAluno);
			listaDeElementos.add(lblNomeTurma);
			listaDeElementos.add(caixaSelecaoTurma);
			listaDeElementos.add(btnCadastroAluno);
			
		}
		
	}
	
	private int recuperarQuantidadeTurma(){
		
		int quantidade = 0;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT count(codigo) AS qtdeCodigo FROM Turma;");
			Controlador.bd.recuperarResultados().next();
			
			quantidade = Controlador.bd.recuperarResultados().getInt("qtdeCodigo");
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return quantidade;
		
	}
	
	private ArrayList<String> recuperaNomeTurma(){
		ArrayList<String> resultado = new ArrayList<>();
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT * FROM Turma");
			
			while(Controlador.bd.recuperarResultados().next()){
				int codigo = Controlador.bd.recuperarResultados().getInt("codigo");
				String nome = Controlador.bd.recuperarResultados().getString("nome");
				
				String linha = codigo + " - " + nome;
				resultado.add(linha);
			}
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
	private boolean cadastrarAluno(String nome, int codigoDaTurma){
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLSemRetorno("INSERT INTO Aluno (nome, frequencia, observacao, codigoTurma) values ('" + nome + "', 0, '(Sem Observacao)', " + codigoDaTurma + ");");
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
}
