package leandrosoft.secoes;

import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import leandrosoft.ferramentas.Controlador;
import leandrosoft.telas.MenuPrincipal;

public class SecaoCadastroTurma {

	public ArrayList<Node> listaDeElementos;

	public SecaoCadastroTurma() {
	
		listaDeElementos = new ArrayList<Node>();
		
		ImageView imgFundo = new ImageView(getClass().getResource("../img/cadTurma.png").toString());
		
		Label lblInfo = new Label("Nome da Turma:");
		lblInfo.setLayoutX(5);
		lblInfo.setLayoutY(130);
		lblInfo.setStyle("-fx-font-size: 30px;");
		
		TextField txtNomeTurma = new TextField();
		txtNomeTurma.setStyle("-fx-font-size: 20px;");
		txtNomeTurma.setLayoutX(240);
		txtNomeTurma.setLayoutY(130);
		
		Button btnCadastroTurma = new Button("Cadastrar");
		btnCadastroTurma.setStyle("-fx-font-size: 20px;");
		btnCadastroTurma.setLayoutX(375);
		btnCadastroTurma.setLayoutY(195);
		
		btnCadastroTurma.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				if(txtNomeTurma.getText().toString().trim().isEmpty()){
					Controlador.mostrarNotificacao(MenuPrincipal.painel, 1, "O campo n�o deve estar vazio.");
					txtNomeTurma.requestFocus();
				}
				else if(txtNomeTurma.getText().toString().trim().length() > 10){
					Controlador.mostrarNotificacao(MenuPrincipal.painel, 1, "O limite do nome da turma � de 10 caracteres.");
					txtNomeTurma.requestFocus();
				}
				else {
					
					if(validarTurma(txtNomeTurma.getText().toString())){
						
						if(cadastrarTurma(txtNomeTurma.getText().toString())){
							Controlador.mostrarNotificacao(MenuPrincipal.painel, 0, "Turma cadastrada.");
							txtNomeTurma.clear();
							txtNomeTurma.requestFocus();
						}
						else{
							Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
						}
						
					}
					else{
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 1, "Turma j� existente.");
					}
					
				}
				
			}
		});
		
		listaDeElementos.add(imgFundo);
		listaDeElementos.add(lblInfo);
		listaDeElementos.add(txtNomeTurma);
		listaDeElementos.add(btnCadastroTurma);
		
	}
	
	private boolean validarTurma(String nomeTurma){
		
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT * FROM Turma WHERE nome = '" + nomeTurma + "';");
			
			if(!Controlador.bd.recuperarResultados().next()){
				resultado = true;
			}
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
	private boolean cadastrarTurma(String nomeTurma){
		
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLSemRetorno("INSERT INTO Turma (nome) value ('" + nomeTurma + "');");
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
		
	}
	
}
