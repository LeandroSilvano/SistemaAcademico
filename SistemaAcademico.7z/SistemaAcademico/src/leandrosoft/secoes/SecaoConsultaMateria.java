package leandrosoft.secoes;

import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import leandrosoft.dialogos.CaixaAlteracaoMateria;
import leandrosoft.dialogos.CaixaExclusaoMateria;
import leandrosoft.ferramentas.Controlador;
import leandrosoft.telas.MenuPrincipal;

public class SecaoConsultaMateria {

	public ArrayList<Node> listaDeElementos;
	
	private ObservableList<String> listaDeMaterias;
	
	public SecaoConsultaMateria() {
		
		listaDeElementos = new ArrayList<Node>();
		
		listaDeMaterias = FXCollections.observableArrayList();
		
		ImageView imgFundo = new ImageView(getClass().getResource("../img/conMateria.png").toString());
		
		listaDeElementos.add(imgFundo);
		
		if(recuperarQuantidadeDeMateria() == 0){
			Label lblInfo = new Label("N�o h� mat�ria cadastrada para consulta.");
			lblInfo.setStyle("-fx-font-size: 20px;");
			lblInfo.setLayoutX(150);
			lblInfo.setLayoutY(200);
			listaDeElementos.add(lblInfo);
		}
		else{
			
			if(preencherListaMateria()){
				
				Label lblNomeMateria = new Label("Selecione a Mat�ria");
				lblNomeMateria.setStyle("-fx-font-size: 20px;");
				lblNomeMateria.setLayoutX(10);
				lblNomeMateria.setLayoutY(80);
				
				ListView<String> visualizadorDeMateria = new ListView<String>();
				visualizadorDeMateria.setItems(listaDeMaterias);
				visualizadorDeMateria.setPrefSize(690, 315);
				visualizadorDeMateria.setLayoutX(10);
				visualizadorDeMateria.setLayoutY(120);
				
				visualizadorDeMateria.getSelectionModel().select(0);
				
				Button btnAlteraMateria = new Button("Alterar");
				btnAlteraMateria.setStyle("-fx-font-size: 20px;");
				btnAlteraMateria.setLayoutX(500);
				btnAlteraMateria.setLayoutY(450);
				
				btnAlteraMateria.setOnAction(new EventHandler<ActionEvent>() {
					
					@Override
					public void handle(ActionEvent arg0) {
						
						String materiaSelecioanda = visualizadorDeMateria.getSelectionModel().getSelectedItem().toString();
						String[] divisor = materiaSelecioanda.split(" - ");
						int codigoMateriaSelecionada = Integer.parseInt(divisor[0]);
						
						CaixaAlteracaoMateria dialogoAlteraMateria = new CaixaAlteracaoMateria(codigoMateriaSelecionada);
						MenuPrincipal.filho.getChildren().add(dialogoAlteraMateria.painel);						
					}
				});
				
				Button btnExcluiMateria = new Button("Excluir");
				btnExcluiMateria.setStyle("-fx-font-size: 20px;");
				btnExcluiMateria.setLayoutX(615);
				btnExcluiMateria.setLayoutY(450);
				
				btnExcluiMateria.setOnAction(new EventHandler<ActionEvent>() {

					@Override
					public void handle(ActionEvent arg0) {
						String materiaSelecioanda = visualizadorDeMateria.getSelectionModel().getSelectedItem().toString();
						String[] divisor = materiaSelecioanda.split(" - ");
						int codigoMateriaSelecionada = Integer.parseInt(divisor[0]);
						
						CaixaExclusaoMateria dialogoExcluiMateria = new CaixaExclusaoMateria(codigoMateriaSelecionada);
						MenuPrincipal.filho.getChildren().add(dialogoExcluiMateria.painel);
					}
				});
				
				listaDeElementos.add(lblNomeMateria);
				listaDeElementos.add(visualizadorDeMateria);
				listaDeElementos.add(btnAlteraMateria);
				listaDeElementos.add(btnExcluiMateria);
			}
			else{
				Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
			}
			
		}
		
		
	}
	
	private int recuperarQuantidadeDeMateria(){
		int quantidade = 0;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT count(codigo) AS qtdeMateria FROM Materia;");
			Controlador.bd.recuperarResultados().next();
			
			quantidade = Controlador.bd.recuperarResultados().getInt("qtdeMateria");
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return quantidade;
	}
	
	private boolean preencherListaMateria(){
		boolean resultado = false;
		
		listaDeMaterias.clear();
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT * FROM Materia ORDER BY nome;");
			
			while(Controlador.bd.recuperarResultados().next()){
				
				String nome = Controlador.bd.recuperarResultados().getString("nome");
				int codigo = Controlador.bd.recuperarResultados().getInt("codigo");
				
				String linha = codigo + " - " + nome;
				listaDeMaterias.add(linha);
				
			}
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
}
