package leandrosoft.secoes;

import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import leandrosoft.ferramentas.Controlador;
import leandrosoft.telas.MenuPrincipal;

public class SecaoCadastroMateria {

	public ArrayList<Node> listaDeElementos;
	
	public SecaoCadastroMateria() {

		listaDeElementos = new ArrayList<Node>();
		
		ImageView imgFundo = new ImageView(getClass().getResource("../img/cadMateria.png").toString());
		
		Label lblInfo = new Label("Nome da Mat�ria:");
		lblInfo.setLayoutX(5);
		lblInfo.setLayoutY(130);
		lblInfo.setStyle("-fx-font-size: 30px;");
		
		TextField txtNomeMateria = new TextField();
		txtNomeMateria.setStyle("-fx-font-size: 20px;");
		txtNomeMateria.setLayoutX(260);
		txtNomeMateria.setLayoutY(130);
		
		Button btnCadastroMateria = new Button("Cadastrar");
		btnCadastroMateria.setStyle("-fx-font-size: 20px;");
		btnCadastroMateria.setLayoutX(398);
		btnCadastroMateria.setLayoutY(195);
		
		btnCadastroMateria.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				
				if(txtNomeMateria.getText().toString().trim().isEmpty()){
					Controlador.mostrarNotificacao(MenuPrincipal.painel, 1, "O campo n�o deve estar vazio.");
					txtNomeMateria.requestFocus();
				}
				else if(txtNomeMateria.getText().toString().trim().length() > 30){
					Controlador.mostrarNotificacao(MenuPrincipal.painel, 1, "O limite do nome da mat�ria � de 30 caracteres.");
					txtNomeMateria.requestFocus();
				}
				else{
					
					if(validarMateria(txtNomeMateria.getText().toString())){
						
						if(cadastrarMateria(txtNomeMateria.getText().toString())){
							Controlador.mostrarNotificacao(MenuPrincipal.painel, 0, "Mat�ria cadastrada.");
							txtNomeMateria.clear();
							txtNomeMateria.requestFocus();
						}
						else{
							Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
						}
						
					}
					else{
						Controlador.mostrarNotificacao(MenuPrincipal.painel, 1, "Mat�ria j� existente.");
						txtNomeMateria.requestFocus();
					}
					
				}
				
			}
		});
		
		listaDeElementos.add(imgFundo);
		listaDeElementos.add(lblInfo);
		listaDeElementos.add(txtNomeMateria);
		listaDeElementos.add(btnCadastroMateria);
		
	}
	
	private boolean validarMateria(String nomeMateria){
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT * FROM Materia WHERE nome = '" + nomeMateria + "';");
			
			if(!Controlador.bd.recuperarResultados().next()){
				resultado = true;
			}
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
	private boolean cadastrarMateria(String nomeMateria){
		boolean resultado = false;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLSemRetorno("INSERT INTO Materia (nome) value ('" + nomeMateria + "');");
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
}
