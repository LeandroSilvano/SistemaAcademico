package leandrosoft.secoes;

import java.util.ArrayList;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import leandrosoft.dialogos.CaixaAlteracaoTurma;
import leandrosoft.dialogos.CaixaExclusaoTurma;
import leandrosoft.ferramentas.Controlador;
import leandrosoft.telas.MenuPrincipal;

public class SecaoConsultaTurma {

	public ArrayList<Node> listaDeElementos;
	
	private ObservableList<String> listaDeTurma;
	
	public SecaoConsultaTurma() {
	
		listaDeElementos = new ArrayList<Node>();
		
		listaDeTurma = FXCollections.observableArrayList();
		
		ImageView imgFundo = new ImageView(getClass().getResource("../img/conTurma.png").toString());
		
		listaDeElementos.add(imgFundo);
		
		if(recuperarQuantidadeTurma() == 0){
			Label lblInfo = new Label("N�o h� turma cadastrada para consulta.");
			lblInfo.setStyle("-fx-font-size: 20px;");
			lblInfo.setLayoutX(150);
			lblInfo.setLayoutY(200);
			listaDeElementos.add(lblInfo);
		}
		else{
			Label lblInfo = new Label("Lista de Turmas:");
			lblInfo.setLayoutX(10);
			lblInfo.setLayoutY(80);
			lblInfo.setStyle("-fx-font-size: 30px;");
			
			ListView<String> visualizadorDeTurma = new ListView<String>();
			visualizadorDeTurma.setItems(listaDeTurma);
			visualizadorDeTurma.setPrefSize(690, 315);
			visualizadorDeTurma.setLayoutX(10);
			visualizadorDeTurma.setLayoutY(120);
			
			Label lblAtalho = new Label("Ou, pesquise por nome");
			lblAtalho.setLayoutX(10);
			lblAtalho.setLayoutY(450);
			lblAtalho.setStyle("-fx-font-size: 20px;");
			
			TextField txtNomeTurma = new TextField();
			txtNomeTurma.setStyle("-fx-font-size: 20px;");
			txtNomeTurma.setLayoutX(10);
			txtNomeTurma.setLayoutY(480);
			txtNomeTurma.setPrefWidth(300);
			
			if(preencherListaTurma("")){
				
				visualizadorDeTurma.getSelectionModel().select(0);
				
				Button btnAlteraTurma = new Button("Alterar");
				btnAlteraTurma.setStyle("-fx-font-size: 20px;");
				btnAlteraTurma.setLayoutX(500);
				btnAlteraTurma.setLayoutY(480);
				
				btnAlteraTurma.setOnAction(new EventHandler<ActionEvent>() {
					
					@Override
					public void handle(ActionEvent arg0) {
						String turmaSelecionada = visualizadorDeTurma.getSelectionModel().getSelectedItem().toString();
						String[] divisor = turmaSelecionada.split(" - ");
						int codigoTurmaSelecionada = Integer.parseInt(divisor[0]);

						CaixaAlteracaoTurma dialogoAlteraTurma = new CaixaAlteracaoTurma(codigoTurmaSelecionada);
						MenuPrincipal.filho.getChildren().add(dialogoAlteraTurma.painel);
					
					}
				});
				
				Button btnExcluiTurma = new Button("Excluir");
				btnExcluiTurma.setStyle("-fx-font-size: 20px;");
				btnExcluiTurma.setLayoutX(615);
				btnExcluiTurma.setLayoutY(480);
				
				btnExcluiTurma.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent e){
						String turmaSelecionada = visualizadorDeTurma.getSelectionModel().getSelectedItem().toString();
						String[] divisor = turmaSelecionada.split(" - ");
						int codigoTurmaSelecionada = Integer.parseInt(divisor[0]);
						
						CaixaExclusaoTurma dialogoExcluiTurma = new CaixaExclusaoTurma(codigoTurmaSelecionada, divisor[1]);
						MenuPrincipal.filho.getChildren().add(dialogoExcluiTurma.painel);
					}
				});
				
				listaDeElementos.add(btnAlteraTurma);
				listaDeElementos.add(btnExcluiTurma);
				
				txtNomeTurma.textProperty().addListener(new ChangeListener<String>() {

					@Override
					public void changed(ObservableValue<? extends String> arg0, String arg1, String arg2) {
						if(txtNomeTurma.getText().toString().isEmpty()){
							preencherListaTurma("");
							visualizadorDeTurma.getSelectionModel().select(0);
							
							btnAlteraTurma.setDisable(false);
							btnExcluiTurma.setDisable(false);
						}
						else{
							preencherListaTurma(txtNomeTurma.getText().toString());
							
							if(listaDeTurma.size() > 0){
								visualizadorDeTurma.getSelectionModel().select(0);
								btnAlteraTurma.setDisable(false);
								btnExcluiTurma.setDisable(false);
							}
							else{
								btnAlteraTurma.setDisable(true);
								btnExcluiTurma.setDisable(true);
							}
						}
						
						
					}
				});
				
			}
			else{
				Controlador.mostrarNotificacao(MenuPrincipal.painel, 2, "Houve um erro.");
			}
			
			listaDeElementos.add(lblInfo);
			listaDeElementos.add(visualizadorDeTurma);
			listaDeElementos.add(lblAtalho);
			listaDeElementos.add(txtNomeTurma);
		}
		
	}
	
	private int recuperarQuantidadeTurma(){
		int quantidade = 0;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT count(codigo) AS qtdeTurma FROM Turma");
			Controlador.bd.recuperarResultados().next();
			
			quantidade = Controlador.bd.recuperarResultados().getInt("qtdeTurma");
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return quantidade;
	}
	
	private boolean preencherListaTurma(String likeParam){
		boolean resultado = false;
		
		listaDeTurma.clear();
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT * FROM Turma WHERE nome like '%" + likeParam + "%' ORDER BY nome;");
			
			while(Controlador.bd.recuperarResultados().next()){
				int codigo = Controlador.bd.recuperarResultados().getInt("codigo");
				String nome = Controlador.bd.recuperarResultados().getString("nome");
				
				String linha = codigo + " - " + nome;
				
				listaDeTurma.add(linha);
			}
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
}
