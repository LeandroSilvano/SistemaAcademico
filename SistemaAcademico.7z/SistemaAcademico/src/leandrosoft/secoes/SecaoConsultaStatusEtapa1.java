package leandrosoft.secoes;

import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import leandrosoft.ferramentas.Controlador;
import leandrosoft.telas.MenuPrincipal;

public class SecaoConsultaStatusEtapa1 {

	public ArrayList<Node> listaDeElementos;
	
	private ObservableList<String> listaDeTurma;

	public SecaoConsultaStatusEtapa1() {
		
		listaDeElementos = new ArrayList<Node>();
		
		listaDeTurma = FXCollections.observableArrayList();
		
		ImageView imgFundo = new ImageView(getClass().getResource("../img/conStatus.png").toString());
		
		listaDeElementos.add(imgFundo);
		
		if(recuperarQuantidadeAluno() == 0){
			Label lblFaltaAluno = new Label("N�o h� aluno cadastrado para a inser��o de status.");
			lblFaltaAluno.setStyle("-fx-font-size: 20px;");
			lblFaltaAluno.setLayoutX(150);
			lblFaltaAluno.setLayoutY(200);
			listaDeElementos.add(lblFaltaAluno);
		}
		else if(recuperarQuantidadeMateria() == 0){
			Label lblFaltaMateria = new Label("N�o h� mat�ria cadastrada para a inser��o de status.");
			lblFaltaMateria.setStyle("-fx-font-size: 20px;");
			lblFaltaMateria.setLayoutX(150);
			lblFaltaMateria.setLayoutY(200);
			listaDeElementos.add(lblFaltaMateria);
		}
		else if(recuperarQuantidadeStatus() == 0){
			Label lblFaltaMateria = new Label("N�o h� status cadastrados para consulta.");
			lblFaltaMateria.setStyle("-fx-font-size: 20px;");
			lblFaltaMateria.setLayoutX(150);
			lblFaltaMateria.setLayoutY(200);
			listaDeElementos.add(lblFaltaMateria);
		}
		else{
			Label lblNomeTurma = new Label("Selecione a Turma");
			lblNomeTurma.setStyle("-fx-font-size: 20px;");
			lblNomeTurma.setLayoutX(10);
			lblNomeTurma.setLayoutY(80);
			
			ListView<String> visualizadorDeTurma = new ListView<String>();
			visualizadorDeTurma.setItems(listaDeTurma);
			visualizadorDeTurma.setPrefSize(690, 315);
			visualizadorDeTurma.setLayoutX(10);
			visualizadorDeTurma.setLayoutY(120);
			
			
			if(atualizarListaDeTurma()){
				visualizadorDeTurma.getSelectionModel().select(0);

				Button btnProceder = new Button("Proceder");
				btnProceder.setStyle("-fx-font-size: 20px;");
				btnProceder.setLayoutX(595);
				btnProceder.setLayoutY(450);
				
				btnProceder.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent e){
						String selecao = visualizadorDeTurma.getSelectionModel().getSelectedItem();
						String[] divisor = selecao.split(" - ");
						
						int codigoTurmaSelecionada = Integer.parseInt(divisor[0]);
						String nomeTurmaSelecionada = divisor[1];
						
						MenuPrincipal.filho.getChildren().clear();
						SecaoConsultaStatusEtapa2 conStatus2 = new SecaoConsultaStatusEtapa2(codigoTurmaSelecionada, nomeTurmaSelecionada);
						MenuPrincipal.filho.getChildren().addAll(conStatus2.listaDeElementos);
						
					}
				});
				
				listaDeElementos.add(btnProceder);

			}
			else{
				Controlador.mostrarNotificacao(MenuPrincipal.painel, 1, "Houve um erro.");
			}
			
			listaDeElementos.add(lblNomeTurma);
			listaDeElementos.add(visualizadorDeTurma);
		}
		
	}
	
	private int recuperarQuantidadeAluno(){
		int quantidade = 0;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT count(codigo) AS qtdeAluno FROM Aluno;");
			Controlador.bd.recuperarResultados().next();
			
			quantidade = Controlador.bd.recuperarResultados().getInt("qtdeAluno");
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return quantidade;
	}
	
	private int recuperarQuantidadeMateria(){
		int quantidade = 0;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT count(codigo) AS qtdeMateria FROM Materia;");
			Controlador.bd.recuperarResultados().next();
			
			quantidade = Controlador.bd.recuperarResultados().getInt("qtdeMateria");
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return quantidade;
	}
	
	private int recuperarQuantidadeStatus(){
		int quantidade = 0;
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT count(codigo) AS qtdeStatus FROM Situacao;");
			Controlador.bd.recuperarResultados().next();
			
			quantidade = Controlador.bd.recuperarResultados().getInt("qtdeStatus");
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return quantidade;
	}
	
	private boolean atualizarListaDeTurma(){
		boolean resultado = false;
		
		listaDeTurma.clear();
		
		try{
			Controlador.bd.conectar();
			
			Controlador.bd.executarSQLComRetorno("SELECT * FROM Turma ORDER BY nome");
			
			while(Controlador.bd.recuperarResultados().next()){
				int codigoTurma = Controlador.bd.recuperarResultados().getInt("codigo");
				String nomeTurma = Controlador.bd.recuperarResultados().getString("nome");
				
				String linha = codigoTurma + " - " + nomeTurma;
				
				listaDeTurma.add(linha);
			}
			
			resultado = true;
			
			Controlador.bd.desconectar();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultado;
	}
	
}
