package leandrosoft.telas;

import javafx.animation.AnimationTimer;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Splash extends Stage{

	private long tempoAtual, tempoInicial, tempoPassado; //Para o Cronometro em tempo real
	
	private ImageView imgLivro, imgIntro;
	
	private AnimationTimer t;
	
	public Splash() {
		
		StackPane painel = new StackPane();
		
		imgLivro = new ImageView(new Image(getClass().getResource("../img/livro.png").toString()));
		imgLivro.setOpacity(0);
		
		imgIntro = new ImageView(new Image(getClass().getResource("../img/intro.png").toString()));
		imgIntro.setOpacity(0);
		
		painel.getChildren().addAll(imgLivro, imgIntro);
		
		this.setScene(new Scene(painel, 800, 600, Color.TRANSPARENT));
		this.initStyle(StageStyle.TRANSPARENT);
		this.show();
		
		tempoInicial = System.currentTimeMillis();

		t = new AnimationTimer() {
			
			@Override
			public void handle(long arg0) {
				//Cron�metro em Milisegundos
				tempoAtual = System.currentTimeMillis(); //Retorna o hor�rio atual do sistema (em milisegundos)
				tempoPassado = tempoAtual - tempoInicial; //Retorna quanto tempo passou (em milisegundos)
				
				//Opacity = opacidade dos objetos: 0 = Invisivel, 1 = Visivel
				//Para aumentar a opacidade aos poucos em fun��o do tempo
				//esse valor desse ser aumentado com um numero decimal bem extenso Ex.: 0.001
				
				//A mesma ideia vale para ScaleX e ScaleY
				
				if((tempoPassado / 1000) < 3){
					imgLivro.setOpacity( ((double)tempoPassado / 10000) * 5);
					imgIntro.setOpacity( ((double)tempoPassado / 10000) * 5);
				}
				else if((tempoPassado / 1000) < 4.5){
					imgLivro.setOpacity(imgLivro.getOpacity() - ( (double)tempoPassado / 200000) );
					imgIntro.setOpacity(imgIntro.getOpacity() - ( (double)tempoPassado / 200000) );
				}
				else{
					this.stop();
					Splash.this.close();
					
					new MenuPrincipal();
				}
				
				imgLivro.setScaleX(imgIntro.getScaleX() + ((double)tempoPassado / 10000) * 0.005);
				imgLivro.setScaleY(imgIntro.getScaleY() + ((double)tempoPassado / 10000) * 0.005);
				
				imgIntro.setScaleX(imgIntro.getScaleX() + ((double)tempoPassado / 10000) * 0.005);
				imgIntro.setScaleY(imgIntro.getScaleY() + ((double)tempoPassado / 10000) * 0.005);

			}
		};
		
		t.start();
		
	}
	
}
