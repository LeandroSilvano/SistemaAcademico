package leandrosoft.telas;

import javafx.animation.AnimationTimer;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import leandrosoft.ferramentas.Controlador;
import leandrosoft.ferramentas.ItemMenu;
import leandrosoft.ferramentas.SubJanela;

public class MenuPrincipal extends Stage{

	public static boolean estaMinimizado;
	
	private ItemMenu imFecha, imMinimiza, cadTurma, cadAluno, cadMateria, cadStatus, conTurma, conAluno, conMateria, conStatus;
	
	public static SubJanela filho;

	public static AnchorPane painel;
	
	public MenuPrincipal() {

		painel = new AnchorPane();
		
		ImageView imgFundo = new ImageView(getClass().getResource("../img/tela.png").toString());
		
		painel.getChildren().addAll(imgFundo);
		
		imFecha = new ItemMenu(925, 7, 46, 46, "fecha");
		imMinimiza = new ItemMenu(872, 7, 46, 46, "minimiza");
		
		cadTurma = new ItemMenu(0, 174, 246, 36, "cadTurma");
		cadAluno = new ItemMenu(0, 210, 246, 30, "cadAluno");
		cadMateria = new ItemMenu(0, 240, 246, 32, "cadMateria");
		cadStatus = new ItemMenu(0, 272, 246, 33, "cadStatus");
		
		conTurma = new ItemMenu(0, 393, 246, 30, "conTurma");
		conAluno = new ItemMenu(0, 423, 246, 34, "conAluno");
		conMateria = new ItemMenu(0, 457, 246, 32, "conMateria");
		conStatus = new ItemMenu(0, 489, 246, 32, "conStatus");
		
		painel.getChildren().addAll(imFecha, imMinimiza, cadTurma, cadAluno, cadMateria, cadStatus, conTurma, conAluno, conMateria, conStatus);

		filho = new SubJanela();
		filho.mudarSecao("cadTurma");
		filho.setLayoutX(263);
		filho.setLayoutY(77);
		painel.getChildren().add(filho);
		
		Scene cena = new Scene(painel, 1024, 768);
		this.setScene(cena);
		this.setTitle("Teste");
		this.initStyle(StageStyle.TRANSPARENT);
		this.show();
		
		Controlador.mostrarNotificacao(painel, 1, "Boas vindas.");
		
		AnimationTimer timer = new AnimationTimer() {
			
			@Override
			public void handle(long arg0) {
				if (estaMinimizado) {
					MenuPrincipal.this.setIconified(true);
					estaMinimizado = false;
				}
			}
		};
		
		timer.start();
		
	}
	
}
